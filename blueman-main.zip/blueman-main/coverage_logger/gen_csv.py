#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Usage:
  ./script.py /path/to/project_dir

This script reads JSON files (afl, field, random) from project_dir/input_dir
and writes corresponding CSVs (time_sec, coverage) to project_dir/csv.
"""
import sys
import os
import json
import csv

# List of expected JSON base names
FILES = ['afl', 'field', 'random']


def json_to_csv(in_path, out_path):
    """Convert a list of JSON entries to a CSV with time (in seconds) and coverage."""
    with open(in_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # write header
        writer.writerow(['time_sec', 'coverage'])
        # write each record, converting time from microseconds to seconds (integer)
        for entry in data:
            time_us = entry.get('time', 0)
            time_sec = time_us // 1_000_000
            writer.writerow([time_sec, entry.get('coverage')])


def main():
    # parse project directory from arguments
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} /path/to/project_dir")
        sys.exit(1)

    project_dir = sys.argv[1]
    input_dir = os.path.join(project_dir, 'input_dir')
    output_dir = os.path.join(project_dir, 'csv')

    # check input_dir exists
    if not os.path.isdir(input_dir):
        print(f"Error: input directory '{input_dir}' does not exist.")
        sys.exit(1)

    # ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # process each file
    for name in FILES:
        in_file = os.path.join(input_dir, name)
        out_file = os.path.join(output_dir, f'{name}.csv')

        if not os.path.isfile(in_file):
            print(f'Warning: {in_file} not found, skipping.')
            continue

        try:
            json_to_csv(in_file, out_file)
            print(f'Written {out_file}')
        except Exception as e:
            print(f'Error converting {in_file}: {e}')

if __name__ == '__main__':
    main()

