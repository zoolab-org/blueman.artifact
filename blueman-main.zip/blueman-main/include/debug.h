#ifndef __DEBUG_H_
#define __DEBUG_H_

#define DEBUG(x...)    fprintf(stderr, x)

#endif
