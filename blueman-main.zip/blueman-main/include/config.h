#ifndef __CONFIG_H_
#define __CONFIG_H_

#define MAX_PACKET_COUNT_PER_ITER 100
#define OUTPUT_PATH "./output"

#endif
